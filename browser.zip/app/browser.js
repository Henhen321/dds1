const logger = require('../helpers/logger');
const random = require('../helpers/random');

const portFinder = require('./functions/portFinder');

const { spawn } = require('child_process');
const CDP = require('chrome-remote-interface');
const net = require('net');

class Browser {
    constructor(options = {}) {
        this.options = options;
        this.process = null;
        this.client = null;
        this.page = null;
        this.port = null;
        this.mouse = {
            click: this.click.bind(this),
            move: this.move.bind(this),
        };
    }

    async launch() {
        const { args = [], headless = false, executablePath = 'google-chrome', proxy = null } = this.options;

        const blockedArgs = [
            '--remote-debugging-port=',
            '--user-data-dir=',
            '--proxy-server='
        ];

        const hasBlockedArgs = args.some((arg) => blockedArgs.some((blockedArg) => arg.includes(blockedArg)));

        if (hasBlockedArgs) {
            const blockedArgsList = args.filter((arg) => blockedArgs.some((blockedArg) => arg.includes(blockedArg))).join(', ');
            throw new Error(`Blocked arguments detected.\nSpectrum noticed that you use the forbidden arguments of start of browser. Not to violate work of browser some arguments are blocked.\nTriggered on: ${blockedArgsList}`);
        }

        if (proxy && !/^http:\/\/\S+$/.test(proxy)) {
            throw new Error(`Invalid proxy format.\nProxies are now supported only format of HTTP. Please, use HTTP proxies.`);
        }

        // searcing available port
        this.port = portFinder.find(8000, 25000);
        const chromeArgs = [
            ...args,
            headless ? '--headless' : '',
            `--remote-debugging-port=${this.port}`,
            "--no-default-browser-check",
            "--no-first-run",
            `--user-data-dir=./cache/${random.randomString(12)}`
        ];

        if (proxy) {
            chromeArgs.push(`--proxy-server=${proxy}`);
        }

        this.process = await spawn(executablePath, chromeArgs);

        await this.waitForPort(this.port);

        //logger.log(`[info/#${this.process.pid}] listening on ${this.port}`);

        this.client = await CDP({ port: this.port });
        this.page = this.client.Page;
        await this.page.enable();
    }

    async waitForPort(port) {
        return new Promise((resolve) => {
            const timer = setInterval(() => {
                const client = new net.Socket();
                client.on('error', (err) => { });
                client.connect(port, '127.0.0.1', () => {
                    clearInterval(timer);
                    client.end();
                    resolve();
                });
            }, 1000);
        });
    }

    async navigate(url) {
        if (!this.page) {
            throw new Error('Browser is not started.\nSpectrum cannot perform actions unless the browser is running/listening on the wrong port.');
        }

        await this.page.navigate({ url });
        await this.page.loadEventFired();

        //logger.log(`[info/#${this.process.pid}] page navigated to ${url}`);
    }

    async click([x, y], button = 'left') {
        if (!this.page) {
            throw new Error('Browser is not started.\nSpectrum cannot perform actions unless the browser is running/listening on the wrong port.');
        }

        const mouseButton = button === 'right' ? 'contextmenu' : 'left';
        await this.client.Input.dispatchMouseEvent({ type: 'mousePressed', button: mouseButton, x, y, clickCount: 1 });
        await this.client.Input.dispatchMouseEvent({ type: 'mouseReleased', button: mouseButton, x, y, clickCount: 1 });

        //logger.log(`[info/#${this.process.pid}] mouse clicked on (${x}, ${y})`);
    }

    async move([x, y]) {
        if (!this.page) {
            throw new Error('Browser is not started.\nSpectrum cannot perform actions unless the browser is running/listening on the wrong port.');
        }

        await this.client.Input.dispatchMouseEvent({ type: 'mouseMoved', x, y });

        //logger.log(`[info/#${this.process.pid}] mouse moved to (${x}, ${y})`);
    }

    async close() {
        //logger.log(`[info/#${this.process.pid}] browser closed`);

        if (this.client) {
            await this.client.close();
        }

        if (this.process) {
            try {
                this.process.kill();
            } catch (error) {
                throw new Error(`Cannot kill browser process.\nIn the future, Spectrum may not be able to open the browser. Please check your open processes and ensure that the browser processes running by Spectrum have been terminated.\nCause: ${error.cause}`);
            }
        }
    }

    async sleep(ms) {
        return new Promise((resolve) => {
            setTimeout(resolve, ms);
        });
    }

    async evaluate(jsCode) {
        if (!this.page) {
            throw new Error('Browser is not started.\nSpectrum cannot execute JavaScript code unless the browser is running/listening on the wrong port.');
        }

        const { result } = await this.client.Runtime.evaluate({ expression: jsCode });
        return result.value;
    }


    async title() {
        if (!this.page) {
            throw new Error('Browser is not started.\nSpectrum cannot get the page title unless the browser is running/listening on the wrong port.');
        }

        const { result } = await this.client.Runtime.evaluate({ expression: 'document.title' });
        return result.value;
    }

    async content() {
        if (!this.page) {
            throw new Error('Browser is not started.\nSpectrum cannot get the page content unless the browser is running/listening on the wrong port.');
        }

        const { result } = await this.client.Runtime.evaluate({ expression: 'document.documentElement.outerHTML' });
        return result.value;
    }

    async cookies() {
        if (!this.page) {
            throw new Error('Browser is not started.\nSpectrum cannot get cookies unless the browser is running/listening on the wrong port.');
        }

        const { cookies } = await this.client.Network.getCookies();
        return cookies.map(cookie => `${cookie.name}=${cookie.value}`).join(';');
    }

    async locator(selector) {
        if (!this.page) {
            throw new Error('Browser is not started.\nSpectrum cannot locate elements unless the browser is running/listening on the wrong port.');
        }

        try {
            const { result } = await this.client.Runtime.evaluate({
                expression: `document.querySelector("${selector}") !== null`
            });

            return result.value;
        } catch (error) {
            return false;
        }
    }

    async version() {
        if (!this.page) {
            throw new Error('Browser is not started.\nSpectrum cannot get the user agent unless the browser is running/listening on the wrong port.');
        }

        return { pid: this.process.pid }
    }

    async userAgent() {
        if (!this.page) {
            throw new Error('Browser is not started.\nSpectrum cannot get the user agent unless the browser is running/listening on the wrong port.');
        }

        const jsCode = 'navigator.userAgent';
        const { result } = await this.client.Runtime.evaluate({ expression: jsCode });
        return result.value;
    }
}

module.exports = Browser;
