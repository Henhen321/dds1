const net = require('net');

function find(min, max) {
    while (true) {
        const port = Math.floor(Math.random() * (max - min + 1)) + min;
        const client = new net.Socket();

        try {
            client.connectSync(port, '127.0.0.1');
            client.end();
        } catch (error) {
            return port;
        }
    }
}

module.exports = {
    find: find
}